<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller {

	public function index()
	{
		$bio = array(
			'namas' =>"Yudha Anang Saputra",
			'alamats' =>"Jl Kembang Turi No 30",
			'emails' =>"yudha.anang21@gmail.com",
			'nims' =>"1541180076",
			'notelps' =>"082247922241",
			);
		$this->load->view('about', $bio);
	}

}

/* End of file About.php */
/* Location: ./application/controllers/About.php */